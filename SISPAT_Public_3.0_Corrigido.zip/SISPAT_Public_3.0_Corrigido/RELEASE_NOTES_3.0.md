# Notas da versão — SISPAT Public 3.0.0

## Correções críticas

- Removidas credenciais em texto simples do código-fonte.
- Senhas locais protegidas por PBKDF2/SHA-256 e migração de credenciais legadas no login.
- Troca obrigatória da senha inicial.
- Usuário não autenticado não recebe mais privilégios administrativos.
- RBAC reforçado em navegação e operações do serviço.
- Endpoints internos de banco e IA protegidos por chave de API em produção.
- IP fictício removido dos termos e logs.
- Alegações falsas de "SHA256 validado" e "PDF autenticado" removidas.
- SHA-256 real adicionado aos termos como evidência de integridade.

## Patrimônio e inventário

- 898 códigos EAN-13 únicos e válidos na base inicial.
- 898 QR Codes únicos.
- Locais do inventário passam a ser derivados dos dados reais cadastrados.
- Histórico de inventários preservado.
- Divergências de localização e ausência registradas por sessão.
- Códigos patrimoniais, EAN e QR podem ser usados na conferência por leitura.

## Gestão operacional

- Empréstimos vencidos passam automaticamente para o status Atrasado.
- Pesquisa global conectada ao catálogo.
- Scanner utiliza a câmera selecionada pelo usuário.
- Restauração da base inicial agora executa a restauração real e exige administrador.
- Relatórios usam a base corrente, sem indicadores fixos de auditorias antigas.

## Nova funcionalidade

### Dossiê Digital do Patrimônio

Cada bem passa a reunir, em uma linha do tempo, dados de aquisição, movimentações, empréstimos, manutenções e atualização cadastral.

## Banco de dados

O schema PostgreSQL foi ampliado para contemplar campos patrimoniais, empréstimos, manutenção e inventário. A API recebeu validação básica e proteção por chave interna.

### Limitação conhecida

O frontend ainda preserva o modo `localStorage` por compatibilidade. Portanto, a centralização PostgreSQL de **todas** as gravações ainda deve ser concluída antes de tratar esta versão como um ambiente multiusuário plenamente centralizado.

## Validação da entrega

- TypeScript: validado com `tsc --noEmit`.
- Base inicial: 898 registros.
- Tombos únicos: 898.
- EAN-13 únicos e válidos: 898.
- QR Codes únicos: 898.
- O pacote de distribuição não inclui `node_modules` para evitar binários incompatíveis entre sistemas operacionais.
