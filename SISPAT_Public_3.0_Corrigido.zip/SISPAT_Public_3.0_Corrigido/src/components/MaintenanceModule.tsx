import React, { useState } from 'react';
import { 
  Wrench, 
  Plus, 
  CheckCircle2, 
  Clock, 
  AlertTriangle, 
  DollarSign, 
  FileText, 
  Building, 
  Search,
  Check
} from 'lucide-react';
import { Manutencao, Patrimonio, UserProfile } from '../types';

interface MaintenanceModuleProps {
  manutencoes: Manutencao[];
  patrimonios: Patrimonio[];
  onSaveManutencao: (manutencao: Manutencao) => void;
  currentUser: UserProfile;
}

export const MaintenanceModule: React.FC<MaintenanceModuleProps> = ({
  manutencoes,
  patrimonios,
  onSaveManutencao,
  currentUser,
}) => {
  const [showNewOSModal, setShowNewOSModal] = useState(false);
  const [selectedPatrimonioId, setSelectedPatrimonioId] = useState('');
  const [defeito, setDefeito] = useState('');
  const [prioridade, setPrioridade] = useState<'Baixa' | 'Média' | 'Alta' | 'Urgente'>('Média');
  const [tecnicoEmpresa, setTecnicoEmpresa] = useState('');
  const [custo, setCusto] = useState('350.00');
  const [previsao, setPrevisao] = useState('2026-08-15');
  const [laudo, setLaudo] = useState('');

  const handleCreateOS = (e: React.FormEvent) => {
    e.preventDefault();
    const pat = patrimonios.find(p => p.id === selectedPatrimonioId || p.codigoPatrimonial === selectedPatrimonioId);
    if (!pat) {
      alert('Selecione um patrimônio válido.');
      return;
    }

    const newOS: Manutencao = {
      id: 'man-' + Date.now(),
      patrimonioId: pat.id,
      codigoPatrimonial: pat.codigoPatrimonial,
      patrimonioNome: pat.nome,
      defeito,
      prioridade,
      tecnicoEmpresa: tecnicoEmpresa || 'Assistência Técnica Especializada',
      custo: parseFloat(custo) || 0,
      dataAbertura: new Date().toISOString().slice(0, 10),
      previsaoConclusao: previsao,
      dataConclusao: null,
      status: 'Em_Andamento',
      laudoTecnico: laudo || 'Ordem de serviço aberta e aguardando perícia do técnico.',
      garantiaServicoMeses: 3,
    };

    onSaveManutencao(newOS);
    setShowNewOSModal(false);
    setSelectedPatrimonioId('');
    setDefeito('');
    setLaudo('');
  };

  const handleConcludeOS = (os: Manutencao) => {
    const updatedOS: Manutencao = {
      ...os,
      status: 'Concluída',
      dataConclusao: new Date().toISOString().slice(0, 10),
      laudoTecnico: os.laudoTecnico + ` | [Serviço concluído com sucesso em ${new Date().toLocaleDateString()}]`,
    };
    onSaveManutencao(updatedOS);
  };

  return (
    <div className="space-y-6">
      
      {/* Header */}
      <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6 shadow-xl flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2 text-amber-400 text-xs font-bold uppercase tracking-wider">
            <Wrench className="w-4 h-4" /> Módulo de Gestão de Manutenções & Garantias
          </div>
          <h2 className="text-xl sm:text-2xl font-black text-white mt-1">
            Ordens de Serviço (OS) de Conservação
          </h2>
          <p className="text-xs text-slate-400 mt-1">
            Acompanhamento de manutenções preventivas e corretivas, técnicos responsáveis, custos e laudos periciais.
          </p>
        </div>

        <button
          onClick={() => setShowNewOSModal(true)}
          className="flex items-center gap-2 bg-amber-600 hover:bg-amber-500 text-slate-950 font-black text-xs px-4 py-2.5 rounded-xl transition shadow-lg shadow-amber-900/20 active:scale-95"
        >
          <Plus className="w-4 h-4" />
          <span>Abrir Ordem de Serviço</span>
        </button>
      </div>

      {/* OS List */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {manutencoes.map(os => {
          const isDone = os.status === 'Concluída';

          return (
            <div 
              key={os.id} 
              className={`bg-slate-900 border rounded-2xl p-5 flex flex-col justify-between space-y-4 shadow-md ${
                isDone ? 'border-slate-800 opacity-80' : 'border-amber-500/40'
              }`}
            >
              <div>
                <div className="flex items-center justify-between gap-2 border-b border-slate-800 pb-3">
                  <span className="font-mono text-xs font-black text-amber-400">
                    {os.codigoPatrimonial}
                  </span>
                  <span className={`text-[10px] font-bold px-2 py-0.5 rounded border ${
                    isDone 
                      ? 'bg-emerald-500/20 text-emerald-400 border-emerald-500/30' 
                      : 'bg-amber-500/20 text-amber-300 border-amber-500/30'
                  }`}>
                    {os.status.replace('_', ' ')}
                  </span>
                </div>

                <h3 className="font-bold text-white text-sm mt-3 line-clamp-2">
                  {os.patrimonioNome}
                </h3>

                <div className="mt-3 space-y-1.5 text-xs text-slate-300">
                  <p><strong className="text-slate-400">Defeito:</strong> {os.defeito}</p>
                  <p><strong className="text-slate-400">Empresa/Técnico:</strong> {os.tecnicoEmpresa}</p>
                  <p><strong className="text-slate-400">Previsão:</strong> {os.previsaoConclusao}</p>
                  <p><strong className="text-slate-400">Custo Est.:</strong> R$ {os.custo.toFixed(2)}</p>
                </div>

                <div className="mt-3 p-2.5 bg-slate-950 rounded-xl border border-slate-800 text-[11px] text-slate-400 italic">
                  "{os.laudoTecnico}"
                </div>
              </div>

              {!isDone && (
                <button
                  onClick={() => handleConcludeOS(os)}
                  className="w-full bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs py-2 rounded-xl transition flex items-center justify-center gap-1.5"
                >
                  <Check className="w-4 h-4" />
                  <span>Concluir Manutenção (Retornar Ativo)</span>
                </button>
              )}
            </div>
          );
        })}
      </div>

      {/* New OS Modal */}
      {showNewOSModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-md">
          <div className="bg-slate-900 border border-slate-800 rounded-3xl max-w-xl w-full p-6 shadow-2xl space-y-4">
            <h2 className="text-lg font-black text-white flex items-center gap-2">
              <Wrench className="w-5 h-5 text-amber-400" /> Abertura de Ordem de Serviço de Manutenção
            </h2>

            <form onSubmit={handleCreateOS} className="space-y-3 text-xs">
              <div>
                <label className="text-slate-300 font-semibold block mb-1">Selecione o Patrimônio *</label>
                <select
                  required
                  value={selectedPatrimonioId}
                  onChange={(e) => setSelectedPatrimonioId(e.target.value)}
                  className="w-full bg-slate-950 text-slate-100 px-3 py-2.5 rounded-xl border border-slate-800"
                >
                  <option value="">-- Escolha um bem do acervo --</option>
                  {patrimonios.map(p => (
                    <option key={p.id} value={p.id}>
                      {p.codigoPatrimonial} - {p.nome} ({p.sala})
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label className="text-slate-300 font-semibold block mb-1">Descrição do Defeito / Falha *</label>
                <textarea
                  required
                  rows={2}
                  value={defeito}
                  onChange={(e) => setDefeito(e.target.value)}
                  placeholder="Descreva o problema observado no equipamento..."
                  className="w-full bg-slate-950 text-slate-100 px-3 py-2 rounded-xl border border-slate-800"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="text-slate-300 font-semibold block mb-1">Empresa / Técnico Responsible</label>
                  <input
                    type="text"
                    value={tecnicoEmpresa}
                    onChange={(e) => setTecnicoEmpresa(e.target.value)}
                    placeholder="Ex: Assistência Autorizada Dell"
                    className="w-full bg-slate-950 text-slate-100 px-3 py-2 rounded-xl border border-slate-800"
                  />
                </div>

                <div>
                  <label className="text-slate-300 font-semibold block mb-1">Custo Estimado (R$)</label>
                  <input
                    type="number"
                    step="0.01"
                    value={custo}
                    onChange={(e) => setCusto(e.target.value)}
                    className="w-full bg-slate-950 text-slate-100 px-3 py-2 rounded-xl border border-slate-800"
                  />
                </div>
              </div>

              <div>
                <label className="text-slate-300 font-semibold block mb-1">Laudo Técnico Inicial / Parecer</label>
                <textarea
                  rows={2}
                  value={laudo}
                  onChange={(e) => setLaudo(e.target.value)}
                  placeholder="Informações do técnico..."
                  className="w-full bg-slate-950 text-slate-100 px-3 py-2 rounded-xl border border-slate-800"
                />
              </div>

              <div className="pt-3 border-t border-slate-800 flex justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setShowNewOSModal(false)}
                  className="px-4 py-2 rounded-xl border border-slate-700 text-slate-300 font-bold"
                >
                  Cancelar
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 rounded-xl bg-amber-600 hover:bg-amber-500 text-slate-950 font-black"
                >
                  Confirmar OS
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

    </div>
  );
};
