import React, { useState, useEffect } from 'react';
import { 
  X, 
  Save, 
  Box, 
  QrCode, 
  DollarSign, 
  MapPin, 
  User, 
  Sparkles,
  CheckCircle2,
  Zap,
  ListPlus,
  FileText,
  AlertCircle,
  Copy,
  Check,
  Building2,
  Trash2,
  Image as ImageIcon,
  Upload
} from 'lucide-react';
import { 
  Patrimonio, 
  CategoriaPatrimonio, 
  EstadoConservacao, 
  SituacaoPatrimonio, 
  UserProfile 
} from '../types';

interface AssetFormModalProps {
  assetToEdit?: Patrimonio | null;
  initialCode?: string;
  onClose: () => void;
  onSave: (patrimonio: Patrimonio | Patrimonio[]) => void;
  currentUser: UserProfile;
}

const EXAMPLE_BULK_TEXT = `COZINHA TÉRREO
32000000010209	FOGÃO INDUSTRIAL 2 BOCAS – COLEI DE PAPEL	OK
32000000012852	REFRIGERADOR CONSUL FROST FREE CRM50 127V	OK
32000000010281	MICROONDAS STYLE	OK`;

export function parseBulkAssetsText(
  rawText: string,
  currentUser: UserProfile
): { items: Patrimonio[]; errors: string[] } {
  const lines = rawText.split('\n');
  const items: Patrimonio[] = [];
  const errors: string[] = [];
  let currentLocation = 'COZINHA TÉRREO';

  lines.forEach((rawLine, index) => {
    const line = rawLine.trim();
    if (!line) return;

    // Check if line is a location header (e.g. "COZINHA TÉRREO", "SALA 101 - BLOCO A")
    const isCodeLine = /^\d{5,}/.test(line) || /^[A-Z0-9\-]{5,}\b/.test(line) || line.includes('\t');

    if (!isCodeLine) {
      currentLocation = line.toUpperCase();
      return;
    }

    // Try splitting by TAB or multiple spaces
    let parts = line.split('\t').map(p => p.trim()).filter(Boolean);

    if (parts.length < 2) {
      // Regex match: [CODE] [DESCRIPTION] [STATUS (optional)]
      const match = line.match(/^([A-Za-z0-9\-]+)\s+(.+?)(?:\s+(OK|BOM|REGULAR|RUIM|INOPERANTE|DANIFICADO|EM\s+USO|DISPONÍVEL))?$/i);
      if (match) {
        parts = [match[1], match[2], match[3] || 'OK'];
      } else {
        const spaceParts = line.split(/\s{2,}/).map(p => p.trim()).filter(Boolean);
        if (spaceParts.length >= 2) {
          parts = spaceParts;
        } else {
          const tokens = line.split(/\s+/);
          if (tokens.length >= 2) {
            const code = tokens[0];
            const possibleStatus = tokens[tokens.length - 1].toUpperCase();
            const statusKnown = ['OK', 'BOM', 'REGULAR', 'RUIM', 'INOPERANTE', 'DANIFICADO', 'EM USO', 'DISPONÍVEL'].includes(possibleStatus);
            if (statusKnown && tokens.length > 2) {
              const name = tokens.slice(1, tokens.length - 1).join(' ');
              parts = [code, name, possibleStatus];
            } else {
              const name = tokens.slice(1).join(' ');
              parts = [code, name, 'OK'];
            }
          } else if (tokens.length === 1 && /^\d{5,}/.test(tokens[0])) {
            // Single code line without name (e.g. 71000000000537)
            parts = [tokens[0], 'EQUIPAMENTO PATRIMONIAL DIVERSO', 'OK'];
          }
        }
      }
    }

    if (parts.length >= 2) {
      const codigoPatrimonial = parts[0].toUpperCase();
      const nome = parts[1];
      const statusRaw = (parts[2] || 'OK').toUpperCase();

      // Determine Categoria based on name keywords
      let categoria: CategoriaPatrimonio = 'Móveis';
      const nameUpper = nome.toUpperCase();
      if (/FOGÃO|REFRIGERADOR|GELADEIRA|MICROONDAS|FREEZER|FORNO|BEBEDOURO|COZINHA|EXAUSTOR/.test(nameUpper)) {
        categoria = 'Eletrodomésticos';
      } else if (/COMPUTADOR|NOTEBOOK|DESKTOP|MONITOR|GABINETE|TECLADO|MOUSE|IMPRESSORA|DELL|LENOVO|HP|CABO/.test(nameUpper)) {
        categoria = 'Informática';
      } else if (/CADEIRA|MESA|ARMÁRIO|ESTANTE|EXPOSITOR|CARRINHO|CALL CENTER|BALCÃO|MÓVEL|GAVETEIRO|SOFÁ/.test(nameUpper)) {
        categoria = 'Móveis';
      } else if (/PROJETOR|TV|TELEVISÃO|CAIXA|SOM|TELÃO|CÂMERA/.test(nameUpper)) {
        categoria = 'Áudio & Vídeo';
      } else if (/SWITCH|ROTEADOR|RACK|MODEM|NETWORK/.test(nameUpper)) {
        categoria = 'Redes';
      } else if (/MICROSCÓPIO|MULTÍMETRO|OSCILOSCÓPIO|MEDIDOR|LABORATÓRIO/.test(nameUpper)) {
        categoria = 'Laboratório';
      }

      // Check for defect or damage keywords in item name or status
      const hasDefectKeyword = /DEFEITO|QUEBRADO|AVARIA|DANIFICADO|INOPERANTE|PÉ QUEBRADO|NÃO DÁ PRA VER|NÃO DA PRA VER|SEM CONSEGUIR|FALTANDO|SEM PLAQUETA/i.test(nome) || /DEFEITO|QUEBRADO|RUIM|DANIFICADO|INOPERANTE/i.test(statusRaw);

      // Determine Situacao and EstadoConservacao
      let situacao: SituacaoPatrimonio = 'Disponível';
      let estadoConservacao: EstadoConservacao = 'Excelente';

      if (hasDefectKeyword) {
        situacao = 'Danificado';
        estadoConservacao = /INOPERANTE|QUEBRADO|DEFEITO/.test(nome.toUpperCase()) ? 'Inoperante' : 'Ruim';
      } else if (statusRaw === 'OK' || statusRaw === 'DISPONÍVEL' || statusRaw === 'BOM') {
        situacao = 'Disponível';
        estadoConservacao = statusRaw === 'OK' ? 'Excelente' : 'Bom';
      } else if (statusRaw === 'EM USO') {
        situacao = 'Em uso';
        estadoConservacao = 'Bom';
      } else if (statusRaw === 'REGULAR') {
        situacao = 'Disponível';
        estadoConservacao = 'Regular';
      } else if (statusRaw === 'RUIM' || statusRaw === 'DANIFICADO') {
        situacao = 'Danificado';
        estadoConservacao = 'Ruim';
      } else if (statusRaw === 'INOPERANTE') {
        situacao = 'Em manutenção';
        estadoConservacao = 'Inoperante';
      }

      const locParts = currentLocation.split(/\s*[\-\/]\s*/);
      const bloco = locParts[0] || currentLocation;
      const sala = locParts[1] || currentLocation;

      items.push({
        id: `pat-${Date.now()}-${index}`,
        codigoPatrimonial,
        codigoBarras: `7896541${Math.floor(1000000 + Math.random() * 9000000)}`,
        qrCode: `SISPAT-${codigoPatrimonial}`,
        nome,
        categoria,
        marca: 'N/I',
        modelo: 'N/I',
        numeroSerie: 'S/N',
        fornecedor: 'Aquisição Pública Direta',
        notaFiscal: `NF-${Math.floor(10000 + Math.random() * 90000)}`,
        dataAquisicao: new Date().toISOString().slice(0, 10),
        valor: 1500.00,
        garantiaVencimento: '2028-12-31',
        vidaUtilAnos: 5,
        estadoConservacao,
        situacao,
        bloco,
        laboratorio: currentLocation,
        sala,
        responsavelNome: currentUser.name,
        responsavelCpf: currentUser.cpf,
        observacoes: hasDefectKeyword 
          ? `⚠️ ATENÇÃO ADMINISTRADOR: Item com aviso/alerta de defeito ou avaria registrado no tombamento: "${nome}".`
          : `Cadastrado em lote no setor: ${currentLocation}`,
        fotoUrl: '',
        dataCadastro: new Date().toISOString(),
        ultimaAtualizacao: new Date().toISOString(),
      });
    } else {
      errors.push(`Linha ${index + 1}: Formato não reconhecido - "${line}"`);
    }
  });

  return { items, errors };
}

export const AssetFormModal: React.FC<AssetFormModalProps> = ({
  assetToEdit,
  initialCode,
  onClose,
  onSave,
  currentUser,
}) => {
  const isEditing = !!assetToEdit;

  // Mode: BULK (Fast text block) or SINGLE (Full detailed form)
  const [activeMode, setActiveMode] = useState<'BULK' | 'SINGLE'>(isEditing ? 'SINGLE' : 'BULK');

  // Bulk mode states
  const [bulkText, setBulkText] = useState<string>(EXAMPLE_BULK_TEXT);
  const [parsedItems, setParsedItems] = useState<Patrimonio[]>([]);
  const [copied, setCopied] = useState(false);

  // Parse bulk text in real-time
  useEffect(() => {
    if (activeMode === 'BULK') {
      const { items } = parseBulkAssetsText(bulkText, currentUser);
      setParsedItems(items);
    }
  }, [bulkText, activeMode, currentUser]);

  // Single mode state
  const defaultTombo = initialCode || (isEditing && assetToEdit ? assetToEdit.codigoPatrimonial : `320000000${Math.floor(100000 + Math.random() * 900000)}`);
  
  const [formData, setFormData] = useState<Partial<Patrimonio>>({
    codigoPatrimonial: defaultTombo,
    codigoBarras: (isEditing && assetToEdit) ? assetToEdit.codigoBarras : `7896541${Math.floor(1000000 + Math.random() * 9000000)}`,
    qrCode: (isEditing && assetToEdit) ? assetToEdit.qrCode : `SISPAT-${defaultTombo}`,
    nome: (isEditing && assetToEdit) ? assetToEdit.nome : '',
    categoria: (isEditing && assetToEdit) ? assetToEdit.categoria : 'Eletrodomésticos',
    marca: (isEditing && assetToEdit) ? assetToEdit.marca : '',
    modelo: (isEditing && assetToEdit) ? assetToEdit.modelo : '',
    numeroSerie: (isEditing && assetToEdit) ? assetToEdit.numeroSerie : '',
    fornecedor: (isEditing && assetToEdit) ? assetToEdit.fornecedor : 'Suprimentos Públicos Ltda',
    notaFiscal: (isEditing && assetToEdit) ? assetToEdit.notaFiscal : `NF-${Math.floor(10000 + Math.random() * 90000)}`,
    dataAquisicao: (isEditing && assetToEdit && assetToEdit.dataAquisicao) ? assetToEdit.dataAquisicao : new Date().toISOString().slice(0, 10),
    valor: (isEditing && assetToEdit) ? assetToEdit.valor : 1500.00,
    garantiaVencimento: (isEditing && assetToEdit) ? assetToEdit.garantiaVencimento : '2028-12-31',
    vidaUtilAnos: (isEditing && assetToEdit) ? assetToEdit.vidaUtilAnos : 5,
    estadoConservacao: (isEditing && assetToEdit) ? assetToEdit.estadoConservacao : 'Excelente',
    situacao: (isEditing && assetToEdit) ? assetToEdit.situacao : 'Disponível',
    bloco: (isEditing && assetToEdit) ? assetToEdit.bloco : 'COZINHA TÉRREO',
    laboratorio: (isEditing && assetToEdit) ? assetToEdit.laboratorio : 'Cozinha Térreo',
    sala: (isEditing && assetToEdit) ? assetToEdit.sala : 'Térreo',
    responsavelNome: (isEditing && assetToEdit) ? assetToEdit.responsavelNome : currentUser.name,
    responsavelCpf: (isEditing && assetToEdit) ? assetToEdit.responsavelCpf : currentUser.cpf,
    observacoes: (isEditing && assetToEdit) ? assetToEdit.observacoes : 'Cadastrado no acervo público de ativos.',
    fotoUrl: (isEditing && assetToEdit) ? (assetToEdit.fotoUrl || '') : '',
  });

  const handleSaveSingle = (e: React.FormEvent) => {
    e.preventDefault();
    try {
      if (!formData.nome || !formData.codigoPatrimonial) {
        alert('Por favor, preencha o nome do bem e o código patrimonial.');
        return;
      }

      const savedItem: Patrimonio = {
        ...(assetToEdit || {}),
        ...(formData as Patrimonio),
        id: assetToEdit?.id || 'pat-' + Date.now(),
        valor: Number(formData.valor) || 0,
        vidaUtilAnos: Number(formData.vidaUtilAnos) || 5,
        dataCadastro: assetToEdit?.dataCadastro || new Date().toISOString(),
        ultimaAtualizacao: new Date().toISOString(),
      };

      onSave(savedItem);
      
      if (isEditing) {
        alert('Patrimônio atualizado com sucesso.');
      } else {
        alert('Patrimônio cadastrado com sucesso.');
      }
    } catch (error) {
      console.error('Erro ao salvar patrimônio:', error);
      alert('Não foi possível atualizar o patrimônio. Tente novamente.');
    }
  };

  const handleSaveBulk = () => {
    try {
      if (parsedItems.length === 0) {
        alert('Nenhum bem patrimonial válido foi reconhecido no texto.');
        return;
      }
      onSave(parsedItems);
      alert(`${parsedItems.length} patrimônios cadastrados com sucesso.`);
    } catch (error) {
      console.error('Erro ao salvar patrimônios em lote:', error);
      alert('Não foi possível cadastrar os patrimônios em lote. Tente novamente.');
    }
  };

  const handleImageUpload = () => {
    // Simulated upload for SISPAT Public
    const mockUrl = prompt('Insira a URL da imagem do patrimônio:', formData.fotoUrl);
    if (mockUrl !== null) {
      setFormData({ ...formData, fotoUrl: mockUrl });
    }
  };

  const handleCopyExample = () => {
    setBulkText(EXAMPLE_BULK_TEXT);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const categories: CategoriaPatrimonio[] = ['Eletrodomésticos', 'Informática', 'Móveis', 'Laboratório', 'Redes', 'Áudio & Vídeo', 'Ferramentas'];
  const estados: EstadoConservacao[] = ['Excelente', 'Bom', 'Regular', 'Ruim', 'Inoperante'];
  const situacoes: SituacaoPatrimonio[] = ['Disponível', 'Em uso', 'Emprestado', 'Em manutenção', 'Danificado', 'Extraviado', 'Baixado', 'Reservado'];

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/85 backdrop-blur-md overflow-y-auto animate-fade-in">
      <div className="bg-slate-900 border border-slate-800 rounded-3xl max-w-4xl w-full my-auto shadow-2xl overflow-hidden flex flex-col max-h-[92vh]">
        
        {/* Header */}
        <div className="bg-slate-950 px-6 py-4 border-b border-slate-800 flex items-center justify-between shrink-0">
          <div className="flex items-center gap-3">
            <div className="p-2.5 bg-gradient-to-r from-emerald-600 to-teal-600 rounded-2xl text-white shadow-lg">
              <Zap className="w-6 h-6 text-amber-300" />
            </div>
            <div>
              <h2 className="text-lg font-extrabold text-white flex items-center gap-2">
                <span>{isEditing ? 'Editar Ficha Patrimonial' : 'Cadastro de Bens Patrimoniais'}</span>
                {!isEditing && (
                  <span className="px-2 py-0.5 text-[10px] uppercase font-bold bg-emerald-500/20 text-emerald-300 border border-emerald-500/30 rounded-full">
                    Padrão Simplificado
                  </span>
                )}
              </h2>
              <p className="text-xs text-slate-400">
                {isEditing 
                  ? `Alterando dados do tombo ${assetToEdit?.codigoPatrimonial}` 
                  : 'Adicione bens individualmente ou cole múltiplos registros em lote de forma instantânea.'}
              </p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-2 text-slate-400 hover:text-white hover:bg-slate-800 rounded-xl transition"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Tab Selector Mode (Only for new asset creation) */}
        {!isEditing && (
          <div className="bg-slate-950/60 px-6 pt-3 border-b border-slate-800/80 flex items-center gap-2">
            <button
              onClick={() => setActiveMode('BULK')}
              className={`flex items-center gap-2 py-2.5 px-4 rounded-t-xl text-xs font-bold transition border-t border-x ${
                activeMode === 'BULK'
                  ? 'bg-slate-900 text-emerald-400 border-slate-800 border-b-transparent shadow-md'
                  : 'text-slate-400 hover:text-slate-200 border-transparent hover:bg-slate-900/40'
              }`}
            >
              <Zap className="w-4 h-4 text-amber-400" />
              <span>Entrada Rápida em Lote (Texto / Tabela)</span>
              {parsedItems.length > 0 && (
                <span className="ml-1 px-2 py-0.5 text-[10px] bg-emerald-600 text-white font-extrabold rounded-full">
                  {parsedItems.length}
                </span>
              )}
            </button>

            <button
              onClick={() => setActiveMode('SINGLE')}
              className={`flex items-center gap-2 py-2.5 px-4 rounded-t-xl text-xs font-bold transition border-t border-x ${
                activeMode === 'SINGLE'
                  ? 'bg-slate-900 text-blue-400 border-slate-800 border-b-transparent shadow-md'
                  : 'text-slate-400 hover:text-slate-200 border-transparent hover:bg-slate-900/40'
              }`}
            >
              <Box className="w-4 h-4 text-blue-400" />
              <span>Formulário Detalhado Individual</span>
            </button>
          </div>
        )}

        {/* Mode 1: Bulk Fast Entry */}
        {activeMode === 'BULK' && !isEditing ? (
          <div className="p-6 overflow-y-auto space-y-5 flex-1 text-xs">
            
            {/* Guide Banner */}
            <div className="bg-slate-950 p-4 rounded-2xl border border-slate-800 space-y-2">
              <div className="flex items-center justify-between">
                <span className="font-extrabold text-white text-xs flex items-center gap-2">
                  <Sparkles className="w-4 h-4 text-amber-400" />
                  Cole ou Digite no Padrão do Recinto / Sala:
                </span>
                <button
                  type="button"
                  onClick={handleCopyExample}
                  className="flex items-center gap-1.5 px-2.5 py-1 bg-slate-800 hover:bg-slate-700 text-slate-200 text-[11px] font-bold rounded-lg border border-slate-700 transition"
                >
                  {copied ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5 text-blue-400" />}
                  <span>{copied ? 'Exemplo Aplicado!' : 'Carregar Exemplo da Cozinha'}</span>
                </button>
              </div>

              <p className="text-[11px] text-slate-400 leading-relaxed">
                Digite a localização no cabeçalho (ex: <strong className="text-slate-200 font-mono">COZINHA TÉRREO</strong>) e em seguida cole os itens contendo <strong className="text-slate-200">TOMBO</strong>, <strong className="text-slate-200">NOME DO BEM</strong> e <strong className="text-slate-200">SITUAÇÃO (OK, BOM, REGULAR)</strong> separados por Tabulação ou Espaços.
              </p>
            </div>

            {/* Input Textarea & Live Preview Split */}
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
              
              {/* Text Input Column */}
              <div className="space-y-2">
                <div className="flex items-center justify-between text-slate-300 font-bold">
                  <label className="flex items-center gap-1.5">
                    <FileText className="w-4 h-4 text-emerald-400" />
                    Bloco de Texto dos Bens
                  </label>
                  <button
                    onClick={() => setBulkText('')}
                    className="text-[10px] text-slate-500 hover:text-rose-400 flex items-center gap-1 font-semibold"
                  >
                    <Trash2 className="w-3 h-3" /> Limpar Texto
                  </button>
                </div>

                <textarea
                  rows={10}
                  value={bulkText}
                  onChange={(e) => setBulkText(e.target.value)}
                  placeholder="Exemplo:&#10;COZINHA TÉRREO&#10;32000000010209  FOGÃO INDUSTRIAL 2 BOCAS  OK&#10;32000000012852  REFRIGERADOR CONSUL FROST FREE  OK"
                  className="w-full bg-slate-950 text-slate-100 font-mono text-xs rounded-2xl p-4 border border-slate-800 focus:outline-none focus:border-emerald-500 focus:ring-1 focus:ring-emerald-500 leading-relaxed resize-none"
                />
              </div>

              {/* Live Parsed Preview Table Column */}
              <div className="space-y-2">
                <div className="flex items-center justify-between text-slate-300 font-bold">
                  <span className="flex items-center gap-1.5">
                    <CheckCircle2 className="w-4 h-4 text-blue-400" />
                    Bens Reconhecidos ({parsedItems.length})
                  </span>
                  {parsedItems.length > 0 && (
                    <span className="text-[10px] text-emerald-400 font-mono font-bold bg-emerald-500/10 px-2 py-0.5 rounded-full border border-emerald-500/20">
                      Prontos para Salvamento
                    </span>
                  )}
                </div>

                <div className="bg-slate-950 border border-slate-800 rounded-2xl p-3 h-[250px] overflow-y-auto space-y-2">
                  {parsedItems.length === 0 ? (
                    <div className="h-full flex flex-col items-center justify-center text-slate-500 text-center p-4">
                      <AlertCircle className="w-8 h-8 mb-2 text-slate-600" />
                      <p className="font-semibold text-slate-400">Nenhum item identificado no texto</p>
                      <p className="text-[10px] text-slate-500 mt-1">Cole os bens no formato do exemplo ao lado.</p>
                    </div>
                  ) : (
                    parsedItems.map((item, idx) => (
                      <div 
                        key={idx} 
                        className="bg-slate-900 border border-slate-800 p-2.5 rounded-xl flex items-center justify-between gap-3 text-xs hover:border-slate-700 transition"
                      >
                        <div className="min-w-0 flex-1">
                          <div className="flex items-center gap-2">
                            <span className="font-mono text-[11px] font-extrabold text-amber-300 shrink-0 bg-amber-400/10 px-1.5 py-0.5 rounded border border-amber-400/20">
                              {item.codigoPatrimonial}
                            </span>
                            <span className="font-bold text-slate-200 truncate">{item.nome}</span>
                          </div>
                          <div className="flex items-center gap-2 text-[10px] text-slate-400 mt-1 font-mono">
                            <span className="flex items-center gap-1 text-slate-300">
                              <Building2 className="w-3 h-3 text-blue-400" />
                              {item.laboratorio}
                            </span>
                            <span>•</span>
                            <span>Cat: {item.categoria}</span>
                          </div>
                        </div>

                        <div className="shrink-0">
                          <span className="px-2 py-0.5 text-[10px] font-bold bg-emerald-500/20 text-emerald-300 border border-emerald-500/30 rounded-full">
                            {item.situacao}
                          </span>
                        </div>
                      </div>
                    ))
                  )}
                </div>
              </div>

            </div>

            {/* Submit Bulk Footer */}
            <div className="pt-4 border-t border-slate-800 flex items-center justify-between shrink-0">
              <span className="text-slate-400 font-mono text-[11px]">
                {parsedItems.length} {parsedItems.length === 1 ? 'bem pronto' : 'bens prontos'} para inclusão imediata
              </span>

              <div className="flex items-center gap-3">
                <button
                  type="button"
                  onClick={onClose}
                  className="px-4 py-2.5 rounded-xl border border-slate-700 text-slate-300 font-bold hover:bg-slate-800 transition"
                >
                  Cancelar
                </button>

                <button
                  type="button"
                  onClick={handleSaveBulk}
                  disabled={parsedItems.length === 0}
                  className="flex items-center gap-2 bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-500 hover:to-teal-500 text-white font-bold px-6 py-2.5 rounded-xl transition shadow-xl shadow-emerald-900/30 disabled:opacity-50 active:scale-95"
                >
                  <Save className="w-4 h-4" />
                  <span>Cadastrar {parsedItems.length} Bens Instantaneamente</span>
                </button>
              </div>
            </div>

          </div>
        ) : (
          /* Mode 2: Single Form Registration */
          <form onSubmit={handleSaveSingle} className="p-6 overflow-y-auto space-y-6 flex-1 text-xs">
            
            {/* Section 0: Imagem do Patrimônio */}
            <div className="space-y-4">
              <h3 className="font-bold text-white text-xs uppercase tracking-wider text-blue-400 flex items-center gap-1.5">
                <ImageIcon className="w-4 h-4" /> Imagem do Patrimônio
              </h3>
              
              <div className="flex flex-col sm:flex-row items-start gap-6 bg-slate-900/50 p-4 rounded-2xl border border-slate-800/50">
                <div className="relative group shrink-0">
                  <div className="w-32 h-32 rounded-2xl overflow-hidden bg-slate-950 border border-slate-800 flex items-center justify-center">
                    {formData.fotoUrl ? (
                      <img 
                        src={formData.fotoUrl} 
                        alt="Preview" 
                        className="w-full h-full object-cover"
                        onError={(e) => {
                          (e.target as HTMLImageElement).src = 'https://images.unsplash.com/photo-1581092160562-40aa08e78837?w=300&h=300&fit=crop';
                        }}
                      />
                    ) : (
                      <div className="text-slate-600 flex flex-col items-center gap-1">
                        <ImageIcon className="w-8 h-8" />
                        <span className="text-[10px] font-bold uppercase">Sem Foto</span>
                      </div>
                    )}
                  </div>
                  <button
                    type="button"
                    onClick={handleImageUpload}
                    className="absolute -bottom-2 -right-2 bg-blue-600 hover:bg-blue-500 text-white p-2 rounded-xl shadow-lg transition active:scale-95"
                    title="Upload/URL de Imagem"
                  >
                    <Upload className="w-4 h-4" />
                  </button>
                </div>
                
                <div className="flex-1 space-y-3 w-full">
                  <p className="text-slate-400 text-[10px] leading-relaxed">
                    A imagem auxilia na identificação visual rápida do bem público durante auditorias e inventários. Você pode inserir uma URL direta ou manter a imagem atual.
                  </p>
                  <div>
                    <label className="text-slate-400 font-semibold text-[10px] uppercase block mb-1">URL da Imagem (Opcional)</label>
                    <input
                      type="text"
                      placeholder="https://exemplo.com/imagem.jpg"
                      value={formData.fotoUrl}
                      onChange={(e) => setFormData({ ...formData, fotoUrl: e.target.value })}
                      className="w-full bg-slate-950 text-slate-100 px-3 py-2 rounded-xl border border-slate-800 focus:outline-none focus:border-blue-500 text-sm"
                    />
                  </div>
                </div>
              </div>
            </div>

            {/* Section 1: Identificação do Bem */}
            <div className="space-y-3">
              <h3 className="font-bold text-white text-xs uppercase tracking-wider text-blue-400 flex items-center gap-1.5">
                <QrCode className="w-4 h-4" /> 1. Identificação de Tombamento
              </h3>

              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                <div>
                  <label className="text-slate-300 font-semibold block mb-1">Cód. Patrimonial (Tombo) *</label>
                  <input
                    type="text"
                    required
                    value={formData.codigoPatrimonial}
                    onChange={(e) => setFormData({ ...formData, codigoPatrimonial: e.target.value, qrCode: `SISPAT-${e.target.value}` })}
                    className="w-full bg-slate-950 text-slate-100 font-mono font-bold px-3 py-2 rounded-xl border border-slate-800 focus:outline-none focus:border-blue-500"
                  />
                </div>

                <div>
                  <label className="text-slate-300 font-semibold block mb-1">Cód. de Barras</label>
                  <input
                    type="text"
                    value={formData.codigoBarras}
                    onChange={(e) => setFormData({ ...formData, codigoBarras: e.target.value })}
                    className="w-full bg-slate-950 text-slate-100 font-mono px-3 py-2 rounded-xl border border-slate-800 focus:outline-none focus:border-blue-500"
                  />
                </div>

                <div>
                  <label className="text-slate-300 font-semibold block mb-1">String QR Code</label>
                  <input
                    type="text"
                    readOnly
                    value={formData.qrCode}
                    className="w-full bg-slate-900 text-blue-400 font-mono px-3 py-2 rounded-xl border border-slate-800"
                  />
                </div>
              </div>
            </div>

            {/* Section 2: Dados do Equipamento */}
            <div className="space-y-3 border-t border-slate-800/80 pt-4">
              <h3 className="font-bold text-white text-xs uppercase tracking-wider text-blue-400 flex items-center gap-1.5">
                <Box className="w-4 h-4" /> 2. Descrição & Categoria
              </h3>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div className="sm:col-span-2">
                  <label className="text-slate-300 font-semibold block mb-1">Nome do Equipamento / Descrição Resumida *</label>
                  <input
                    type="text"
                    required
                    placeholder="Ex: FOGÃO INDUSTRIAL 2 BOCAS"
                    value={formData.nome}
                    onChange={(e) => setFormData({ ...formData, nome: e.target.value })}
                    className="w-full bg-slate-950 text-slate-100 font-medium px-3 py-2 rounded-xl border border-slate-800 focus:outline-none focus:border-blue-500"
                  />
                </div>

                <div>
                  <label className="text-slate-300 font-semibold block mb-1">Categoria</label>
                  <select
                    value={formData.categoria}
                    onChange={(e) => setFormData({ ...formData, categoria: e.target.value as CategoriaPatrimonio })}
                    className="w-full bg-slate-950 text-slate-100 px-3 py-2 rounded-xl border border-slate-800 focus:outline-none focus:border-blue-500"
                  >
                    {categories.map(c => <option key={c} value={c}>{c}</option>)}
                  </select>
                </div>

                <div>
                  <label className="text-slate-300 font-semibold block mb-1">Marca / Fabricante</label>
                  <input
                    type="text"
                    placeholder="Ex: Consul, Dell, Epson"
                    value={formData.marca}
                    onChange={(e) => setFormData({ ...formData, marca: e.target.value })}
                    className="w-full bg-slate-950 text-slate-100 px-3 py-2 rounded-xl border border-slate-800 focus:outline-none focus:border-blue-500"
                  />
                </div>
              </div>
            </div>

            {/* Section 3: Localização & Custódia */}
            <div className="space-y-3 border-t border-slate-800/80 pt-4">
              <h3 className="font-bold text-white text-xs uppercase tracking-wider text-blue-400 flex items-center gap-1.5">
                <MapPin className="w-4 h-4" /> 3. Localização & Responsável
              </h3>

              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                <div>
                  <label className="text-slate-300 font-semibold block mb-1">Bloco / Setor</label>
                  <input
                    type="text"
                    value={formData.bloco}
                    onChange={(e) => setFormData({ ...formData, bloco: e.target.value })}
                    className="w-full bg-slate-950 text-slate-100 px-3 py-2 rounded-xl border border-slate-800 focus:outline-none focus:border-blue-500"
                  />
                </div>

                <div>
                  <label className="text-slate-300 font-semibold block mb-1">Recinto / Dependência</label>
                  <input
                    type="text"
                    value={formData.laboratorio}
                    onChange={(e) => setFormData({ ...formData, laboratorio: e.target.value })}
                    className="w-full bg-slate-950 text-slate-100 px-3 py-2 rounded-xl border border-slate-800 focus:outline-none focus:border-blue-500"
                  />
                </div>

                <div>
                  <label className="text-slate-300 font-semibold block mb-1">Sala / Térreo</label>
                  <input
                    type="text"
                    value={formData.sala}
                    onChange={(e) => setFormData({ ...formData, sala: e.target.value })}
                    className="w-full bg-slate-950 text-slate-100 px-3 py-2 rounded-xl border border-slate-800 focus:outline-none focus:border-blue-500"
                  />
                </div>
              </div>
            </div>

            {/* Section 4: Situação & Conservação */}
            <div className="space-y-3 border-t border-slate-800/80 pt-4">
              <h3 className="font-bold text-white text-xs uppercase tracking-wider text-blue-400 flex items-center gap-1.5">
                <CheckCircle2 className="w-4 h-4" /> 4. Situação Operacional & Estado
              </h3>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="text-slate-300 font-semibold block mb-1">Estado de Conservação</label>
                  <select
                    value={formData.estadoConservacao}
                    onChange={(e) => setFormData({ ...formData, estadoConservacao: e.target.value as EstadoConservacao })}
                    className="w-full bg-slate-950 text-slate-100 px-3 py-2 rounded-xl border border-slate-800 focus:outline-none focus:border-blue-500"
                  >
                    {estados.map(e => <option key={e} value={e}>{e}</option>)}
                  </select>
                </div>

                <div>
                  <label className="text-slate-300 font-semibold block mb-1">Situação Operacional</label>
                  <select
                    value={formData.situacao}
                    onChange={(e) => setFormData({ ...formData, situacao: e.target.value as SituacaoPatrimonio })}
                    className="w-full bg-slate-950 text-slate-100 px-3 py-2 rounded-xl border border-slate-800 focus:outline-none focus:border-blue-500"
                  >
                    {situacoes.map(s => <option key={s} value={s}>{s}</option>)}
                  </select>
                </div>
              </div>
            </div>

            {/* Submit Footer */}
            <div className="pt-4 border-t border-slate-800 flex items-center justify-end gap-3 shrink-0">
              <button
                type="button"
                onClick={onClose}
                className="px-4 py-2.5 rounded-xl border border-slate-700 text-slate-300 font-bold hover:bg-slate-800 transition"
              >
                Cancelar
              </button>

              <button
                type="submit"
                className="flex items-center gap-2 bg-emerald-600 hover:bg-emerald-500 text-white font-bold px-6 py-2.5 rounded-xl transition shadow-lg shadow-emerald-900/30 active:scale-95"
              >
                <Save className="w-4 h-4" />
                <span>{isEditing ? 'Salvar Alterações' : 'Concluir Cadastro Individual'}</span>
              </button>
            </div>

          </form>
        )}

      </div>
    </div>
  );
};
