import React, { useState } from 'react';
import { 
  Handshake, 
  Plus, 
  CheckCircle2, 
  Clock, 
  UserCheck, 
  Building,
  ArrowRight,
  PenTool,
  FileDown,
  ShieldCheck,
  FileText
} from 'lucide-react';
import { Emprestimo, Patrimonio, UserProfile } from '../types';
import { SignatureCanvasModal } from './SignatureCanvasModal';
import { generateLoanAgreementPDF } from '../utils/loanPdfGenerator';

interface LoanModuleProps {
  emprestimos: Emprestimo[];
  patrimonios: Patrimonio[];
  onSaveEmprestimo: (emprestimo: Emprestimo) => void;
  currentUser: UserProfile;
}

export const LoanModule: React.FC<LoanModuleProps> = ({
  emprestimos,
  patrimonios,
  onSaveEmprestimo,
  currentUser,
}) => {
  const [showModal, setShowModal] = useState(false);
  const [selectedPatrimonioId, setSelectedPatrimonioId] = useState('');
  const [servidorNome, setServidorNome] = useState('');
  const [cpfServidor, setCpfServidor] = useState('');
  const [cargoServidor, setCargoServidor] = useState('Servidor Público / Docente');
  const [setor, setSetor] = useState('Coordenação Acadêmica');
  const [previsaoDevolucao, setPrevisaoDevolucao] = useState('2026-08-30');
  const [observacoes, setObservacoes] = useState('');
  
  const [signatureDataUrl, setSignatureDataUrl] = useState<string | null>(null);
  const [showSignatureModal, setShowSignatureModal] = useState(false);
  const [signatureForEmp, setSignatureForEmp] = useState<Emprestimo | null>(null);

  const getClientIp = async () => {
    try {
      const res = await fetch('/api/client-info', { headers: { 'Accept': 'application/json' } });
      if (!res.ok) return 'não coletado';
      const data = await res.json();
      return data.ip || 'não coletado';
    } catch { return 'não coletado'; }
  };

  const handleCreateLoan = async (e: React.FormEvent) => {
    e.preventDefault();
    const pat = patrimonios.find(p => p.id === selectedPatrimonioId || p.codigoPatrimonial === selectedPatrimonioId);
    if (!pat) {
      alert('Selecione um bem válido.');
      return;
    }

    const clientIp = signatureDataUrl ? await getClientIp() : undefined;
    const newEmp: Emprestimo = {
      id: 'emp-' + Date.now(),
      patrimonioId: pat.id,
      codigoPatrimonial: pat.codigoPatrimonial,
      patrimonioNome: pat.nome,
      servidorNome: servidorNome || currentUser.name,
      cpfServidor: cpfServidor || currentUser.cpf || '123.456.789-00',
      cargoServidor: cargoServidor || 'Servidor Público',
      setor: setor || 'Gabinete / Diretoria',
      dataRetirada: new Date().toISOString().slice(0, 10),
      previsaoDevolucao,
      dataDevolucao: null,
      status: 'Ativo',
      observacoes: observacoes || 'Termo de cautela de uso temporário assinado eletronicamente.',
      assinaturaDigitalUrl: signatureDataUrl || undefined,
      assinaturaIp: clientIp,
      assinaturaDataHora: signatureDataUrl ? new Date().toLocaleString('pt-BR') : undefined,
      termoPdfGerado: true,
    };

    onSaveEmprestimo(newEmp);
    setShowModal(false);
    setSelectedPatrimonioId('');
    setServidorNome('');
    setSignatureDataUrl(null);
  };

  const handleDevolver = (emp: Emprestimo) => {
    const updated: Emprestimo = {
      ...emp,
      status: 'Devolvido',
      dataDevolucao: new Date().toISOString().slice(0, 10),
      observacoes: emp.observacoes + ` | [Devolvido em perfeitas condições em ${new Date().toLocaleDateString()}]`,
    };
    onSaveEmprestimo(updated);
  };

  const handleDownloadPDF = async (emp: Emprestimo) => {
    const pat = patrimonios.find(p => p.id === emp.patrimonioId || p.codigoPatrimonial === emp.codigoPatrimonial);
    const doc = await generateLoanAgreementPDF(emp, pat);
    doc.save(`termo-cautela-${emp.codigoPatrimonial}-${emp.id.slice(-6)}.pdf`);
  };

  const handleSignExisting = (emp: Emprestimo) => {
    setSignatureForEmp(emp);
    setShowSignatureModal(true);
  };

  const handleSaveExistingSignature = async (dataUrl: string) => {
    if (signatureForEmp) {
      const clientIp = await getClientIp();
      const updated: Emprestimo = {
        ...signatureForEmp,
        assinaturaDigitalUrl: dataUrl,
        assinaturaIp: clientIp,
        assinaturaDataHora: new Date().toLocaleString('pt-BR'),
      };
      onSaveEmprestimo(updated);
      setSignatureForEmp(null);
    } else {
      setSignatureDataUrl(dataUrl);
    }
  };

  return (
    <div className="space-y-6">
      
      {/* Header */}
      <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6 shadow-xl flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2 text-indigo-400 text-xs font-bold uppercase tracking-wider">
            <Handshake className="w-4 h-4" /> Módulo de Empréstimos & Termos de Cautela Digitais
          </div>
          <h2 className="text-xl sm:text-2xl font-black text-white mt-1">
            Controle de Retiradas com Assinatura na Tela
          </h2>
          <p className="text-xs text-slate-400 mt-1">
            Rastreie equipamentos cedidos temporariamente com termo de cautela PDF gerado na hora e assinatura eletrônica.
          </p>
        </div>

        <button
          onClick={() => {
            setSignatureDataUrl(null);
            setShowModal(true);
          }}
          className="flex items-center gap-2 bg-indigo-600 hover:bg-indigo-500 text-white font-bold text-xs px-4 py-2.5 rounded-xl transition shadow-lg shadow-indigo-900/20 active:scale-95"
        >
          <Plus className="w-4 h-4" />
          <span>Registrar Novo Empréstimo</span>
        </button>
      </div>

      {/* Loan Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {emprestimos.map(emp => {
          const isReturned = emp.status === 'Devolvido';
          const hasSignature = Boolean(emp.assinaturaDigitalUrl);

          return (
            <div 
              key={emp.id}
              className={`bg-slate-900 border rounded-2xl p-5 flex flex-col justify-between space-y-4 shadow-md ${
                isReturned ? 'border-slate-800 opacity-80' : 'border-indigo-500/40'
              }`}
            >
              <div>
                <div className="flex items-center justify-between gap-2 border-b border-slate-800 pb-3">
                  <span className="font-mono text-xs font-black text-indigo-400">
                    {emp.codigoPatrimonial}
                  </span>
                  <div className="flex items-center gap-1.5">
                    {hasSignature && (
                      <span className="text-[10px] font-bold px-2 py-0.5 rounded border bg-sky-500/20 text-sky-300 border-sky-500/30 flex items-center gap-1">
                        <ShieldCheck className="w-3 h-3 text-sky-400" /> Assinado
                      </span>
                    )}
                    <span className={`text-[10px] font-bold px-2 py-0.5 rounded border ${
                      isReturned 
                        ? 'bg-emerald-500/20 text-emerald-400 border-emerald-500/30' 
                        : 'bg-indigo-500/20 text-indigo-300 border-indigo-500/30'
                    }`}>
                      {emp.status}
                    </span>
                  </div>
                </div>

                <h3 className="font-bold text-white text-sm mt-3 line-clamp-2">
                  {emp.patrimonioNome}
                </h3>

                <div className="mt-3 space-y-1.5 text-xs text-slate-300">
                  <p><strong className="text-slate-400">Servidor Cautelado:</strong> {emp.servidorNome}</p>
                  <p><strong className="text-slate-400">Setor / Destino:</strong> {emp.setor}</p>
                  <p><strong className="text-slate-400">Data Retirada:</strong> {emp.dataRetirada}</p>
                  <p><strong className="text-slate-400">Retorno Previsto:</strong> {emp.previsaoDevolucao}</p>
                </div>

                {hasSignature && (
                  <div className="mt-3 p-2 bg-slate-950/80 rounded-xl border border-slate-800 flex items-center gap-2">
                    <img
                      src={emp.assinaturaDigitalUrl}
                      alt="Assinatura"
                      className="h-8 max-w-[120px] object-contain bg-slate-900 rounded p-1 border border-slate-800"
                    />
                    <div className="text-[9px] text-slate-400 font-mono">
                      <p className="text-sky-400 font-bold">Assinatura Válida</p>
                      <p>{emp.assinaturaDataHora || 'Registrado'}</p>
                    </div>
                  </div>
                )}

                <div className="mt-3 p-2.5 bg-slate-950 rounded-xl border border-slate-800 text-[11px] text-slate-400 italic">
                  "{emp.observacoes}"
                </div>
              </div>

              <div className="space-y-2 pt-2 border-t border-slate-800">
                {!hasSignature && (
                  <button
                    onClick={() => handleSignExisting(emp)}
                    className="w-full bg-sky-950 hover:bg-sky-900 text-sky-300 border border-sky-800 font-bold text-xs py-2 rounded-xl transition flex items-center justify-center gap-1.5"
                  >
                    <PenTool className="w-3.5 h-3.5 text-sky-400" />
                    <span>Colher Assinatura Digital</span>
                  </button>
                )}

                <button
                  onClick={() => handleDownloadPDF(emp)}
                  className="w-full bg-slate-800 hover:bg-slate-700 text-slate-200 font-bold text-xs py-2 rounded-xl transition flex items-center justify-center gap-1.5"
                >
                  <FileDown className="w-3.5 h-3.5 text-indigo-400" />
                  <span>Baixar Termo em PDF</span>
                </button>

                {!isReturned && (
                  <button
                    onClick={() => handleDevolver(emp)}
                    className="w-full bg-indigo-600 hover:bg-indigo-500 text-white font-bold text-xs py-2.5 rounded-xl transition flex items-center justify-center gap-1.5"
                  >
                    <CheckCircle2 className="w-4 h-4" />
                    <span>Registrar Devolução do Bem</span>
                  </button>
                )}
              </div>
            </div>
          );
        })}
      </div>

      {/* New Loan Modal */}
      {showModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-md">
          <div className="bg-slate-900 border border-slate-800 rounded-3xl max-w-xl w-full p-6 shadow-2xl space-y-4">
            <h2 className="text-lg font-black text-white flex items-center gap-2">
              <Handshake className="w-5 h-5 text-indigo-400" /> Emissão de Termo de Empréstimo / Cautela
            </h2>

            <form onSubmit={handleCreateLoan} className="space-y-3 text-xs">
              <div>
                <label className="text-slate-300 font-semibold block mb-1">Selecione o Patrimônio *</label>
                <select
                  required
                  value={selectedPatrimonioId}
                  onChange={(e) => setSelectedPatrimonioId(e.target.value)}
                  className="w-full bg-slate-950 text-slate-100 px-3 py-2.5 rounded-xl border border-slate-800"
                >
                  <option value="">-- Escolha um bem disponível --</option>
                  {patrimonios.filter(p => p.situacao !== 'Baixado').map(p => (
                    <option key={p.id} value={p.id}>
                      {p.codigoPatrimonial} - {p.nome} ({p.situacao})
                    </option>
                  ))}
                </select>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="text-slate-300 font-semibold block mb-1">Nome do Servidor *</label>
                  <input
                    type="text"
                    required
                    placeholder="Nome completo do beneficiário"
                    value={servidorNome}
                    onChange={(e) => setServidorNome(e.target.value)}
                    className="w-full bg-slate-950 text-slate-100 px-3 py-2 rounded-xl border border-slate-800"
                  />
                </div>

                <div>
                  <label className="text-slate-300 font-semibold block mb-1">CPF do Servidor</label>
                  <input
                    type="text"
                    placeholder="123.456.789-00"
                    value={cpfServidor}
                    onChange={(e) => setCpfServidor(e.target.value)}
                    className="w-full bg-slate-950 text-slate-100 px-3 py-2 rounded-xl border border-slate-800"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="text-slate-300 font-semibold block mb-1">Cargo / Função</label>
                  <input
                    type="text"
                    value={cargoServidor}
                    onChange={(e) => setCargoServidor(e.target.value)}
                    className="w-full bg-slate-950 text-slate-100 px-3 py-2 rounded-xl border border-slate-800"
                  />
                </div>

                <div>
                  <label className="text-slate-300 font-semibold block mb-1">Setor / Projeto</label>
                  <input
                    type="text"
                    value={setor}
                    onChange={(e) => setSetor(e.target.value)}
                    className="w-full bg-slate-950 text-slate-100 px-3 py-2 rounded-xl border border-slate-800"
                  />
                </div>
              </div>

              <div>
                <label className="text-slate-300 font-semibold block mb-1">Previsão de Devolução</label>
                <input
                  type="date"
                  value={previsaoDevolucao}
                  onChange={(e) => setPrevisaoDevolucao(e.target.value)}
                  className="w-full bg-slate-950 text-slate-100 px-3 py-2 rounded-xl border border-slate-800"
                />
              </div>

              {/* Signature Section inside Modal */}
              <div className="p-3 bg-slate-950 rounded-2xl border border-slate-800 flex items-center justify-between">
                <div>
                  <p className="font-bold text-white text-xs">Assinatura Eletrônica do Servidor</p>
                  <p className="text-[10px] text-slate-400">
                    {signatureDataUrl ? '✓ Assinatura coletada com sucesso' : 'Opcional: Desenhe na tela para autencidade'}
                  </p>
                </div>
                {signatureDataUrl ? (
                  <div className="flex items-center gap-2">
                    <img src={signatureDataUrl} alt="Visto" className="h-8 bg-slate-900 border border-slate-700 rounded p-1" />
                    <button
                      type="button"
                      onClick={() => setShowSignatureModal(true)}
                      className="text-xs text-sky-400 font-bold hover:underline"
                    >
                      Refazer
                    </button>
                  </div>
                ) : (
                  <button
                    type="button"
                    onClick={() => setShowSignatureModal(true)}
                    className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-sky-600 hover:bg-sky-500 text-white font-bold text-xs"
                  >
                    <PenTool className="w-3.5 h-3.5" /> Assinar na Tela
                  </button>
                )}
              </div>

              <div>
                <label className="text-slate-300 font-semibold block mb-1">Observações do Termo de Cautela</label>
                <textarea
                  rows={2}
                  value={observacoes}
                  onChange={(e) => setObservacoes(e.target.value)}
                  className="w-full bg-slate-950 text-slate-100 px-3 py-2 rounded-xl border border-slate-800"
                />
              </div>

              <div className="pt-3 border-t border-slate-800 flex justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setShowModal(false)}
                  className="px-4 py-2 rounded-xl border border-slate-700 text-slate-300 font-bold"
                >
                  Cancelar
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white font-bold flex items-center gap-2"
                >
                  <Handshake className="w-4 h-4" /> Emitir Empréstimo & Termo
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Signature Canvas Popup */}
      <SignatureCanvasModal
        isOpen={showSignatureModal}
        onClose={() => setShowSignatureModal(false)}
        servidorNome={signatureForEmp ? signatureForEmp.servidorNome : (servidorNome || currentUser.name)}
        onSaveSignature={handleSaveExistingSignature}
      />

    </div>
  );
};

