# SISPAT Public 3.0

Sistema de controle patrimonial, inventário, auditoria, empréstimos e manutenção de bens, com leitura por QR Code/EAN-13, relatórios e dossiê digital do patrimônio.

## Requisitos

- Node.js 20 ou superior
- npm
- PostgreSQL (opcional nesta versão; necessário para os endpoints de banco)

## Instalação local

1. Copie `.env.example` para `.env` e configure apenas as variáveis que utilizar.
2. Instale as dependências em uma instalação limpa:
   ```bash
   npm ci
   ```
3. Execute em desenvolvimento:
   ```bash
   npm run dev
   ```
4. Para validar TypeScript:
   ```bash
   npm run lint
   ```
5. Para gerar a versão de produção:
   ```bash
   npm run build
   npm start
   ```

> `node_modules` não acompanha o pacote de distribuição. Isso evita incompatibilidade de binários entre Windows, Linux e ambientes de deploy.

## Segurança da versão 3.0

- Senhas locais são derivadas com PBKDF2 + SHA-256, salt individual e 150.000 iterações.
- O primeiro acesso exige troca da senha temporária.
- Perfis e operações sensíveis são verificados também na camada de serviço.
- Endpoints internos de banco e IA podem ser protegidos por `SISPAT_API_KEY` em produção.
- Termos de empréstimo usam SHA-256 real para verificação de integridade do conteúdo.
- O hash de integridade não equivale a assinatura digital ICP-Brasil.
- IP de evidência é coletado pelo servidor quando disponível; não há IP fictício no documento.

## Principais atualizações

- 898 patrimônios da base inicial com EAN-13 único e válido e QR Code único.
- Inventário baseado nos blocos, laboratórios e salas realmente cadastrados.
- Histórico de sessões de inventário e registro de divergências.
- Empréstimos vencidos marcados automaticamente como atrasados.
- Conferência patrimonial calculada com a base atual, sem totais demonstrativos fixos.
- Dossiê Digital do Patrimônio com aquisição, movimentações, empréstimos e manutenções.
- Pesquisa global conectada ao catálogo patrimonial.
- Seleção de câmera aplicada ao scanner QR.
- Restauração de base funcional e restrita a administrador.
- Estrutura PostgreSQL ampliada para acompanhar os principais campos do frontend.

## Persistência e multiusuário

A versão 3.0 mantém compatibilidade com o modo local do sistema existente. Os endpoints PostgreSQL foram ampliados e protegidos, mas a persistência completa de todos os módulos do frontend ainda não foi migrada integralmente para o servidor. Para uma implantação realmente multiusuário, com diversos computadores usando uma única fonte de verdade, a próxima etapa é concluir a migração de todas as operações do `StorageService` para APIs transacionais no PostgreSQL.

## Backup

Antes de restaurar a base inicial ou realizar alterações estruturais, exporte os relatórios/dados necessários. Em produção, utilize também rotina de backup do PostgreSQL.
